import React, { useState } from "react";
import { View, Text, TextInput, Pressable, StyleSheet, Alert, KeyboardAvoidingView, Platform } from "react-native";
import { login } from "../api/auth";
import { setToken } from "../storage/token";

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState("scanner@bbf.com");
  const [password, setPassword] = useState("");
  const [deviceName, setDeviceName] = useState("Scanner Device");
  const [loading, setLoading] = useState(false);

  async function onLogin() {
    try {
      setLoading(true);
      const data = await login({ email, password, device_name: deviceName });
      await setToken(data.token);
      navigation.reset({ index: 0, routes: [{ name: "Home" }] });
    } catch (e) {
      const msg =
        e?.response?.data?.message ||
        e?.response?.data?.error ||
        (e?.response?.data?.errors ? JSON.stringify(e.response.data.errors) : null) ||
        "Check credentials / API";
      Alert.alert("Login failed", msg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView style={styles.wrap} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <View style={styles.card}>
        <Text style={styles.title}>BBF Check-in</Text>
        <Text style={styles.sub}>Login with your scanner/admin account.</Text>

        <Text style={styles.label}>Email</Text>
        <TextInput value={email} onChangeText={setEmail} style={styles.input} autoCapitalize="none" keyboardType="email-address" />

        <Text style={styles.label}>Password</Text>
        <TextInput value={password} onChangeText={setPassword} style={styles.input} secureTextEntry />

        <Text style={styles.label}>Device name</Text>
        <TextInput value={deviceName} onChangeText={setDeviceName} style={styles.input} />

        <Pressable style={[styles.btn, loading && { opacity: 0.7 }]} onPress={onLogin} disabled={loading}>
          <Text style={styles.btnText}>{loading ? "Logging in..." : "Login"}</Text>
        </Pressable>

        <Text style={styles.hint}>
          Demo users:\nAdmin: admin@bbf.com / Admin123!\nScanner: scanner@bbf.com / ChangeMe123!
        </Text>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, justifyContent: "center", alignItems: "center", padding: 18, backgroundColor: "#0b1220" },
  card: { width: "100%", maxWidth: 420, backgroundColor: "#101a2d", borderRadius: 18, padding: 18, borderWidth: 1, borderColor: "#1e2b45" },
  title: { color: "white", fontSize: 28, fontWeight: "800", marginBottom: 6, textAlign: "center" },
  sub: { color: "#b6c2d9", marginBottom: 14, textAlign: "center" },
  label: { color: "#b6c2d9", marginTop: 10, marginBottom: 6, fontWeight: "600" },
  input: { backgroundColor: "#0b1220", color: "white", padding: 12, borderRadius: 12, borderWidth: 1, borderColor: "#1e2b45" },
  btn: { marginTop: 16, backgroundColor: "#2f6bff", padding: 14, borderRadius: 12, alignItems: "center" },
  btnText: { color: "white", fontWeight: "800" },
  hint: { color: "#7f8fb3", marginTop: 14, lineHeight: 18 }
});
