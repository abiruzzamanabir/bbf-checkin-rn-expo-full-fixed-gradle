import React, { useEffect, useMemo, useState } from "react";
import { View, Text, StyleSheet, TextInput, FlatList, Pressable, Modal } from "react-native";
import { getHistory, clearHistory } from "../storage/scans";
import { useRole } from "../context/RoleContext";

function getName(item) {
  return (
    item?.name ||
    item?.full_name ||
    item?.member_name ||
    item?.attendee_name ||
    item?.visitor_name ||
    item?.profile?.name ||
    item?.user?.name ||
    item?.data?.name ||
    ""
  );
}

function getCompany(item) {
  return (
    item?.company ||
    item?.company_name ||
    item?.organization ||
    item?.org ||
    item?.org_name ||
    item?.profile?.company ||
    item?.user?.company ||
    item?.data?.company ||
    item?.data?.organization ||
    item?.data?.org ||
    ""
  );
}

function getDesignation(item) {
  return (
    item?.designation ||
    item?.title ||
    item?.role ||
    item?.profile?.designation ||
    item?.user?.designation ||
    item?.data?.designation ||
    ""
  );
}

function formatLine(item) {
  const name = getName(item);
  const company = getCompany(item);
  const who = name ? `${name}${company ? ` · ${company}` : ""}` : "";
  const base = `${item.direction} · ${item.time_label || ""}`.trim();
  return who ? `${who}
${base}` : base;
}

export default function HistoryScreen() {
  const { role } = useRole();
  const [items, setItems] = useState([]);
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState(null);

  const load = async () => {
    const list = await getHistory();
    setItems(list);
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    const qq = (q || "").trim().toLowerCase();
    if (!qq) return items;
    return items.filter((it) => {
      const hay = `${it.qr_code || ""} ${getName(it)} ${getCompany(it)} ${it.direction || ""} ${it.status || ""}`.toLowerCase();
      return hay.includes(qq);
    });
  }, [items, q]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Scan History</Text>

      <View style={styles.searchRow}>
        <TextInput
          value={q}
          onChangeText={setQ}
          placeholder="Search name, company, QR, status…"
          placeholderTextColor="rgba(255,255,255,0.45)"
          style={styles.search}
        />
        <Pressable onPress={load} style={styles.btn}>
          <Text style={styles.btnText}>Refresh</Text>
        </Pressable>
      </View>

      {role === "ADMIN" && (
        <Pressable
          onPress={async () => {
            await clearHistory();
            await load();
          }}
          style={[styles.btn, { marginBottom: 10, alignSelf: "flex-start" }]}
        >
          <Text style={styles.btnText}>Clear history</Text>
        </Pressable>
      )}

      <FlatList
        data={filtered}
        keyExtractor={(it) => it.id}
        contentContainerStyle={{ paddingBottom: 24 }}
        renderItem={({ item }) => (
          <Pressable style={styles.card} onPress={() => setSelected(item)}>
            <View style={styles.row}>
              <View style={{ flex: 1 }}>
                <Text style={styles.name} numberOfLines={1}>
                  {getName(item) || "Unknown Guest"}
                </Text>
                {!!getCompany(item) && (
                  <Text style={styles.company} numberOfLines={1}>
                    {getCompany(item)}
                  </Text>
                )}
              </View>
              <Text style={[styles.badge, badgeStyle(item.status)]}>
                {item.status === "OFFLINE_SAVED" ? "OFFLINE" : item.status}
              </Text>
            </View>
            <Text style={styles.line}>{formatLine(item)}</Text>
            {!!item.message && <Text style={styles.sub}>{item.message}</Text>}
          </Pressable>
        )}
        ListEmptyComponent={<Text style={styles.empty}>No history yet.</Text>}
      />

      {/* Detail modal */}
      <Modal
        visible={!!selected}
        transparent
        animationType="fade"
        onRequestClose={() => setSelected(null)}
      >
        <Pressable style={styles.modalBackdrop} onPress={() => setSelected(null)}>
          <Pressable style={styles.modalCard} onPress={() => {}}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Member Details</Text>
              <Pressable onPress={() => setSelected(null)} style={styles.modalClose}>
                <Text style={styles.modalCloseText}>✕</Text>
              </Pressable>
            </View>

            <View style={styles.modalSection}>
              <Text style={styles.modalName}>{getName(selected) || "Unknown Guest"}</Text>
              {!!getCompany(selected) && <Text style={styles.modalCompany}>{getCompany(selected)}</Text>}
              {!!getDesignation(selected) && <Text style={styles.modalMeta}>{getDesignation(selected)}</Text>}
            </View>

            <View style={styles.modalSection}>
              <DetailRow label="Direction" value={selected?.direction} />
              <DetailRow label="Time" value={selected?.time_label || selected?.time || ""} />
              <DetailRow
                label="Status"
                value={selected?.status === "OFFLINE_SAVED" ? "OFFLINE" : selected?.status}
              />
              {!!selected?.device_name && <DetailRow label="Recorded by" value={selected.device_name} />}
              {!!selected?.qr_code && <DetailRow label="QR Code" value={selected.qr_code} />}
              {!!selected?.org && <DetailRow label="Organization" value={selected.org} />}
            </View>

            {!!selected?.message && (
              <View style={styles.modalSection}>
                <Text style={styles.modalMessage}>{selected.message}</Text>
              </View>
            )}

            <View style={styles.modalActions}>
              <Pressable style={styles.modalBtn} onPress={() => setSelected(null)}>
                <Text style={styles.modalBtnText}>Close</Text>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

function DetailRow({ label, value }) {
  return (
    <View style={styles.detailRow}>
      <Text style={styles.detailLabel}>{label}</Text>
      <Text style={styles.detailValue} numberOfLines={2}>
        {value || "—"}
      </Text>
    </View>
  );
}

function badgeStyle(status) {
  if (status === "SUCCESS") return styles.badgeSuccess;
  if (status === "FAIL") return styles.badgeFail;
  if (status === "OFFLINE_SAVED") return styles.badgeOffline;
  return styles.badgeNeutral;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0B1220", padding: 14 },
  title: { color: "white", fontSize: 18, fontWeight: "900", marginBottom: 12 },
  searchRow: { flexDirection: "row", gap: 10, marginBottom: 12 },
  search: {
    flex: 1,
    height: 44,
    borderRadius: 14,
    paddingHorizontal: 12,
    backgroundColor: "rgba(255,255,255,0.06)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.10)",
    color: "white",
    fontWeight: "700",
  },
  btn: {
    height: 44,
    paddingHorizontal: 14,
    borderRadius: 14,
    backgroundColor: "rgba(255,255,255,0.10)",
    alignItems: "center",
    justifyContent: "center",
  },
  btnText: { color: "white", fontWeight: "900" },
  card: {
    backgroundColor: "rgba(255,255,255,0.06)",
    borderRadius: 16,
    padding: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.10)",
  },
  row: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 },
  name: { color: "white", fontWeight: "900", fontSize: 15 },
  company: { color: "rgba(255,255,255,0.65)", fontWeight: "700", fontSize: 12, marginTop: 2 },
  badge: {
    color: "white",
    fontWeight: "900",
    fontSize: 12,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    overflow: "hidden",
  },
  badgeSuccess: { backgroundColor: "rgba(103,232,167,0.18)" },
  badgeFail: { backgroundColor: "rgba(255,138,138,0.18)" },
  badgeOffline: { backgroundColor: "rgba(121,194,255,0.18)" },
  badgeNeutral: { backgroundColor: "rgba(255,255,255,0.10)" },
  line: { color: "rgba(255,255,255,0.85)", marginTop: 8, fontWeight: "700", lineHeight: 18 },
  sub: { color: "rgba(255,255,255,0.60)", marginTop: 6, fontWeight: "600" },
  empty: { color: "rgba(255,255,255,0.70)", marginTop: 20 },

  /* Modal */
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.55)",
    justifyContent: "center",
    padding: 16,
  },
  modalCard: {
    backgroundColor: "#101A33",
    borderRadius: 18,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.10)",
    padding: 14,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  modalTitle: { color: "white", fontSize: 16, fontWeight: "900" },
  modalClose: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.08)",
  },
  modalCloseText: { color: "white", fontWeight: "900" },
  modalSection: {
    backgroundColor: "rgba(255,255,255,0.06)",
    borderRadius: 14,
    padding: 12,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.10)",
    marginTop: 10,
  },
  modalName: { color: "white", fontSize: 16, fontWeight: "1000" },
  modalCompany: { color: "rgba(255,255,255,0.75)", marginTop: 4, fontWeight: "700" },
  modalMeta: { color: "rgba(255,255,255,0.60)", marginTop: 4, fontWeight: "700" },
  detailRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 10,
    paddingVertical: 6,
  },
  detailLabel: { color: "rgba(255,255,255,0.60)", fontWeight: "800", width: 96 },
  detailValue: { color: "white", fontWeight: "800", flex: 1, textAlign: "right" },
  modalMessage: { color: "rgba(255,255,255,0.85)", fontWeight: "700", lineHeight: 18 },
  modalActions: { flexDirection: "row", justifyContent: "flex-end", marginTop: 12 },
  modalBtn: {
    height: 44,
    paddingHorizontal: 16,
    borderRadius: 14,
    backgroundColor: "rgba(255,255,255,0.10)",
    alignItems: "center",
    justifyContent: "center",
  },
  modalBtnText: { color: "white", fontWeight: "900" },
});
