import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  TextInput,
  Modal,
  FlatList,
  Animated,
  Easing,
  Platform,
} from "react-native";
import { CameraView, useCameraPermissions } from "expo-camera";
import { BlurView } from "expo-blur";
import * as Network from "expo-network";
import * as Device from "expo-device";
import { Audio } from "expo-av";

import { submitScan } from "../api/scan";
import { searchTickets } from "../api/tickets";
import { fetchEventStats } from "../api/stats";
import { getSettings, setSettings as persistSettings } from "../storage/settings";
import {
  enqueueOfflineScan,
  getOfflineQueue,
  setOfflineQueue,
  pushHistory,
} from "../storage/scans";
import { useRole } from "../context/RoleContext";

const QR_LEAVE_MS = 650;

function nowLabel() {
  try {
    return new Date().toLocaleTimeString();
  } catch {
    return "";
  }
}


function pick(obj, paths) {
  for (const p of paths) {
    const parts = p.split(".");
    let cur = obj;
    for (const k of parts) cur = cur?.[k];
    if (cur !== undefined && cur !== null && String(cur).trim() !== "") return cur;
  }
  return "";
}

function normalizeApi(res) {
  // submitScan() returns response body; many APIs wrap payload in `data`
  return res?.data ?? res ?? {};
}


export default function ScannerScreen({ navigation }) {
  const [permission, requestPermission] = useCameraPermissions();
  const { role } = useRole();

  // Settings (already in your app)
  const [settings, setSettingsState] = useState({
    event: null,
    gate: null,
    direction: "IN",
  });

  // Network
  const [online, setOnline] = useState(true);

  // Sync progress UI
  const [syncing, setSyncing] = useState(false);
  const [syncProgress, setSyncProgress] = useState(0);
  const [syncTotal, setSyncTotal] = useState(0);

  // Live counters
  const [insideCount, setInsideCount] = useState(0);
  const [outsideCount, setOutsideCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [serverTime, setServerTime] = useState("");

  // Last scanned card
  const [lastCard, setLastCard] = useState(null);

// Manual add/search
const [manualOpen, setManualOpen] = useState(false);
const [manualQ, setManualQ] = useState("");
const [manualItems, setManualItems] = useState([]);
const [manualLoading, setManualLoading] = useState(false);
const [manualSelected, setManualSelected] = useState(null);


async function refreshStats(forceEventSlug) {
  const event_slug = forceEventSlug || settings?.event?.slug;
  if (!event_slug) return;
  if (!online) return;
  try {
    const data = await fetchEventStats(event_slug);
    setInsideCount(Number(data?.inside_count ?? 0));
    setOutsideCount(Number(data?.outside_count ?? 0));
    setTotalCount(Number(data?.total_tickets ?? 0));
    setServerTime(String(data?.server_time ?? ""));
  } catch (e) {
    // counters are non-blocking
  }
}

async function runTicketSearch(q) {
  const event_slug = settings?.event?.slug;
  if (!event_slug) {
    setManualItems([]);
    return;
  }
  setManualLoading(true);
  try {
    const data = await searchTickets({ event_slug, q, limit: 20 });
    setManualItems(Array.isArray(data?.items) ? data.items : []);
  } catch (e) {
    setManualItems([]);
  } finally {
    setManualLoading(false);
  }
}

// Scan state machine
  const [scanState, setScanState] = useState("SEARCHING");
  // SEARCHING | FOUND | VALIDATING | SUCCESS | FAIL | OFFLINE
  const [scanLocked, setScanLocked] = useState(false);

  // “QR must leave frame” gate
  const qrVisibleRef = useRef(false);
  const qrLeaveTimerRef = useRef(null);
  const lastQrRef = useRef(null);
  const processingRef = useRef(false);

  // Sounds (different IN vs OUT)
  const inSoundRef = useRef(null);
  const outSoundRef = useRef(null);
  const failSoundRef = useRef(null);

  // Animations
  const scanLineY = useRef(new Animated.Value(0)).current;
  const pulse = useRef(new Animated.Value(0)).current;

  const direction = settings.direction || "IN";
  const showBlur = scanState === "SEARCHING";

  // ---- Error classification ----
  function isNetworkError(err) {
    // Axios: network/timeout errors typically have no `response`
    if (!err) return true;
    if (err.response) return false;
    return true;
  }

  function extractApiMessage(err) {
    try {
      const d = err?.response?.data;
      if (!d) return "";
      if (typeof d === "string") return d;
      return d.message || d.error || d.errors?.[0] || "";
    } catch {
      return "";
    }
  }

  useEffect(() => {
    (async () => {
      const s = await getSettings();
      setSettingsState(s);

      // Load sounds (WAV files included in this zip)
      const inS = await Audio.Sound.createAsync(
        require("../../assets/sounds/in.wav"),
      );
      inSoundRef.current = inS.sound;

      const outS = await Audio.Sound.createAsync(
        require("../../assets/sounds/out.wav"),
      );
      outSoundRef.current = outS.sound;

      const failS = await Audio.Sound.createAsync(
        require("../../assets/sounds/fail.wav"),
      );
      failSoundRef.current = failS.sound;
    })();

    return () => {
      inSoundRef.current?.unloadAsync?.();
      outSoundRef.current?.unloadAsync?.();
      failSoundRef.current?.unloadAsync?.();
    };
  }, []);

  useEffect(() => {
    // Network check loop
    const tick = async () => {
      try {
        const st = await Network.getNetworkStateAsync();
        const isOn = !!(st.isConnected && st.isInternetReachable !== false);
        setOnline(isOn);
        if (isOn) {
          // Opportunistic sync
          await syncOfflineQueue();
        }
      } catch {
        setOnline(false);
      }
    };

    tick();
    const id = setInterval(tick, 3000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    // Refresh counters when event changes + poll every 10s
    refreshStats();
    const id = setInterval(() => refreshStats(), 10000);
    return () => clearInterval(id);
  }, [settings?.event?.slug, online]);

  useEffect(() => {
    // Scan line animation
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(scanLineY, {
          toValue: 1,
          duration: 1400,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(scanLineY, {
          toValue: 0,
          duration: 1400,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [scanLineY]);

  useEffect(() => {
    const isFound = scanState === "FOUND" || scanState === "VALIDATING";
    const p = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 650, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0, duration: 650, useNativeDriver: true }),
      ]),
    );
    if (isFound) p.start();
    else p.stop();
    return () => p.stop();
  }, [scanState, pulse]);

  const statusText = useMemo(() => {
    if (scanState === "SEARCHING") return { t: "🔍 Looking for QR code", s: "Align the code inside the frame" };
    if (scanState === "FOUND") return { t: "✅ QR detected", s: "Hold steady…" };
    if (scanState === "VALIDATING") return { t: "⏳ Validating", s: "Please wait" };
    if (scanState === "SUCCESS") return { t: "✅ Recorded", s: direction === "IN" ? "Entry recorded" : "Exit recorded" };
    if (scanState === "OFFLINE") return { t: "✅ Saved offline", s: "Will sync automatically when online" };
    return { t: "❌ Failed", s: "Please try again" };
  }, [scanState, direction]);

  async function syncOfflineQueue() {
    // prevent multiple overlapping sync loops
    if (syncing) return;
    const q = await getOfflineQueue();
    if (!q.length) return;

    setSyncing(true);
    setSyncTotal(q.length);
    setSyncProgress(0);

    const remaining = [];
    for (let i = 0; i < q.length; i++) {
      try {
        const p = q[i];
        await submitScan(p);
        setSyncProgress((x) => x + 1);
      } catch (e) {
        // If the server rejects it (4xx/5xx), drop it from queue and log as FAIL_SYNC
        if (!isNetworkError(e)) {
          await pushHistory({
            id: `SYNCFAIL-${Date.now()}-${i}`,
            ts: Date.now(),
            time_label: nowLabel(),
            direction: p?.direction || direction,
            status: "FAIL",
            qr_code: p?.qr_code,
            message: extractApiMessage(e) || "Sync failed (server rejected).",
          });
          // still advance progress so the UI doesn't get stuck at 0
          setSyncProgress((x) => x + 1);
        } else {
          remaining.push(q[i]);
        }
      }
    }

    await setOfflineQueue(remaining);

    setTimeout(() => {
      setSyncing(false);
      setSyncProgress(0);
      setSyncTotal(0);
    }, 700);
  }

  async function playForDirection(ok) {
    try {
      if (!ok) return await failSoundRef.current?.replayAsync?.();
      if (direction === "IN") return await inSoundRef.current?.replayAsync?.();
      return await outSoundRef.current?.replayAsync?.();
    } catch {}
  }

  function lockUntilQrLeaves() {
    setScanLocked(true);
    clearTimeout(qrLeaveTimerRef.current);

    qrLeaveTimerRef.current = setTimeout(() => {
      // if we did not see a QR again within QR_LEAVE_MS, unlock
      qrVisibleRef.current = false;
      lastQrRef.current = null;
      setScanLocked(false);
      setScanState("SEARCHING");
    }, QR_LEAVE_MS);
  }

  
async function onScanPayload({ qr_code }) {
  if (!qr_code) return;
  if (scanLocked) return;
  if (processingRef.current) return;

  // prevent same QR repeatedly unless it leaves frame
  if (lastQrRef.current && lastQrRef.current === qr_code) {
    lockUntilQrLeaves();
    return;
  }

  processingRef.current = true;
  lastQrRef.current = qr_code;

  setScanState("VALIDATING");
  await playForDirection(true); // tiny feedback; real sound played after result

  const payload = {
    event_slug: settings?.event?.slug,
    gate_code: settings?.gate?.code,
    direction: settings?.direction || "IN",
    device_uuid: Device.osBuildId || Device.modelId || "mobile",
    qr_code,
  };

  try {
    if (!online) throw new Error("OFFLINE");
    const res = await submitScan(payload);
    const body = normalizeApi(res);

    const ok = String(body?.status || "").toUpperCase() === "OK";
    await playForDirection(ok);

    const attendee = body?.attendee || body?.data?.attendee || {};
    const ticket = body?.ticket || body?.data?.ticket || {};
    const name = pick(body, [
      "attendee.full_name",
      "data.attendee.full_name",
      "person.full_name",
      "data.person.full_name",
      "attendee.name",
      "data.attendee.name",
      "name",
    ]) || "Unknown";

    const company = pick(body, ["attendee.company", "data.attendee.company", "company"]) || "";
    const designation = pick(body, ["attendee.designation", "data.attendee.designation", "designation"]) || "";

    const card = {
      id: `${Date.now()}`,
      ts: Date.now(),
      time_label: nowLabel(),
      direction: payload.direction,
      status: ok ? "OK" : "FAIL",
      qr_code,
      message: body?.message || body?.reason || (ok ? "Recorded." : "Failed."),
      name,
      company,
      designation,
      data: body,
    };

    setLastCard(card);
    await pushHistory(card);

    setScanState(ok ? "SUCCESS" : "FAIL");
    refreshStats();
  } catch (e) {
    // offline queue
    await enqueueOfflineScan(payload);
    const card = {
      id: `${Date.now()}`,
      ts: Date.now(),
      time_label: nowLabel(),
      direction: payload.direction,
      status: "OFFLINE",
      qr_code,
      message: "Saved offline (will sync when online).",
      name: "Offline scan",
      data: { offline: true },
    };
    setLastCard(card);
    await pushHistory(card);
    setScanState("OFFLINE");
  } finally {
    processingRef.current = false;
    lockUntilQrLeaves();
  }
}

const onBarcodeScanned = async ({ data }) => {
const qr_code = String(data?.data ?? data?.rawValue ?? "").trim();
    if (!qr_code) return;
    return onScanPayload({ qr_code });
  }

  // legacy handler removed
  const __unused = 0;

qrVisibleRef.current = true;
    clearTimeout(qrLeaveTimerRef.current);

    // Always extend the leave-frame timer whenever we see *any* QR event.
    // This prevents repeated scans of the same QR staying in the frame.
    lockUntilQrLeaves();

    // If locked, keep waiting for QR to leave frame
    if (scanLocked) return;

    // If same QR still visible, ignore
    if (lastQrRef.current === data) return;

    // Guard against parallel scans
    if (processingRef.current) return;
    processingRef.current = true;

    lastQrRef.current = data;
    setScanState("FOUND");

    const event_slug = settings?.event?.slug || settings?.event?.value || settings?.event?.id || settings?.event?.event_slug;
    const gate_code = settings?.gate?.code || settings?.gate?.value || settings?.gate?.id || settings?.gate?.gate_code;

    const payload = {
      qr_code: data,
      event_slug,
      direction,
      gate_code,
      device_uuid: Device.osInternalBuildId || Device.modelId || Device.modelName || "device",
    };

    // If missing settings, treat as fail (but still show QR)
    if (!event_slug) {
      const deviceName =
        settings?.gate?.name ||
        settings?.gate?.label ||
        settings?.gate?.code ||
        gate_code ||
        "Device";

      const defaultMsg =
        direction === "IN"
          ? `Entry recorded by ${deviceName}`
          : `Exit recorded by ${deviceName}`;

      const item = {
        id: `OK-${Date.now()}`,
        ts: Date.now(),
        time_label: nowLabel(),
        direction,
        status: "SUCCESS",
        qr_code: data,
        name: name || "Unknown Guest",
        company: company || "",
        designation: designation || "",
        device_name: deviceName,
        message:
          res?.message ||
          dataObj?.message ||
          dataObj?.status_message ||
          defaultMsg,
      };
      await pushHistory(item);
      setLastCard({
        name: "Not recorded",
        company: "",
        time: item.time_label,
        status: item.status,
        message: item.message,
      });
      setScanState("FAIL");
      await playForDirection(false);
      processingRef.current = false;
      return;
    }

    try {
      setScanState("VALIDATING");
      const res = await submitScan(payload);

      // Normalize API response and extract user fields across common shapes
      const dataObj = normalizeApi(res);

      const name = pick(dataObj, [
        "name",
        "full_name",
        "member_name",
        "attendee_name",
        "visitor_name",
        "user.name",
        "member.name",
        "profile.name",
        "data.name",
        "data.user.name",
        "data.member.name",
        "data.profile.name",
      ]);

      const company = pick(dataObj, [
        "company",
        "company_name",
        "organization",
        "org",
        "org_name",
        "user.company",
        "member.company",
        "profile.company",
        "data.company",
        "data.organization",
        "data.org",
        "data.org_name",
        "data.user.company",
        "data.member.company",
      ]);

      const designation = pick(dataObj, [
        "designation",
        "title",
        "role",
        "user.designation",
        "member.designation",
        "profile.designation",
        "data.designation",
        "data.user.designation",
        "data.member.designation",
      ]);

      const item = {
        id: `OK-${Date.now()}`,
        ts: Date.now(),
        time_label: nowLabel(),
        direction,
        status: "SUCCESS",
        qr_code: data,
        name,
        company,
        message: res?.message || res?.status_message || "",
      };
      await pushHistory(item);

      setLastCard({
        name: item.name || "Unknown Guest",
        company: item.company || "",
        time: item.time_label,
        status: item.status,
        message: item.message,
      });

      if (direction === "IN") setInsideCount((c) => c + 1);
      else setOutsideCount((c) => c + 1);

      setScanState("SUCCESS");
      await playForDirection(true);
    } catch (e) {
      // Only treat as offline if it's a real network/timeout issue.
      if (isNetworkError(e)) {
        await enqueueOfflineScan(payload);
        const item = {
          id: `OFF-${Date.now()}`,
          ts: Date.now(),
          time_label: nowLabel(),
          direction,
          status: "OFFLINE_SAVED",
          qr_code: data,
          message: "Saved offline (will sync automatically).",
        };
        await pushHistory(item);
        setLastCard({
          name: "Saved Offline",
          company: "",
          time: item.time_label,
          status: item.status,
          message: item.message,
        });
        setScanState("OFFLINE");
        await playForDirection(true);
      } else {
        const msg = extractApiMessage(e) || "Scan failed. Please try again.";
        const item = {
          id: `FAIL-${Date.now()}`,
          ts: Date.now(),
          time_label: nowLabel(),
          direction,
          status: "FAIL",
          qr_code: data,
          message: msg,
        };
        await pushHistory(item);
        setLastCard({
          name: "Not recorded",
          company: "",
          time: item.time_label,
          status: item.status,
          message: msg,
        });
        setScanState("FAIL");
        await playForDirection(false);
      }
    } finally {
      processingRef.current = false;
    }
  };

  // Note: We intentionally do NOT extend the leave-frame timer on render.
  // Many Android devices stop emitting events when onBarcodeScanned is unset.
  // We keep onBarcodeScanned enabled and extend the timer on actual scan callbacks.

  const setDirection = async (next) => {
    const updated = { ...settings, direction: next };
    setSettingsState(updated);
    await persistSettings(updated);
  };

  const onLongPressMode = () => {
    // quick access to admin unlock screen
    navigation.navigate("Admin");
  };

  if (!permission) return null;

  if (!permission.granted) {
    return (
      <View style={styles.center}>
        <Text style={styles.text}>Camera permission is required to scan QR codes.</Text>
        <Pressable style={styles.primaryBtn} onPress={requestPermission}>
          <Text style={styles.primaryBtnText}>Allow Camera</Text>
        </Pressable>
      </View>
    );
  }

  const syncPct = syncTotal > 0 ? Math.min(100, Math.round((syncProgress / syncTotal) * 100)) : 0;

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} style={styles.iconBtn}>
          <Text style={styles.iconText}>←</Text>
        </Pressable>

        <Text style={styles.headerTitle}>Scan QR</Text>

        <View style={[styles.netBadge, online ? styles.netOn : styles.netOff]}>
          <Text style={styles.netText}>{online ? "ONLINE" : "OFFLINE"}</Text>
        </View>
      </View>

      {/* Counters */}
      <View style={styles.countersRow}>
        <View style={styles.counterCard}>
          <Text style={styles.counterLabel}>Inside now</Text>
          <Text style={styles.counterValue}>{insideCount}</Text>
        </View>
        <View style={styles.counterCard}>
          <Text style={styles.counterLabel}>Outside</Text>
          <Text style={styles.counterValue}>{outsideCount}</Text>
        </View>
        <View style={styles.counterCard}>
          <Text style={styles.counterLabel}>Total issued</Text>
          <Text style={styles.counterValue}>{totalCount}</Text>
        </View>
      </View>

      {serverTime ? (
        <View style={[styles.counterCard, { marginHorizontal: 14, marginBottom: 10 }]}>
          <Text style={styles.counterLabel}>Server time</Text>
          <Text style={[styles.counterValue, { fontSize: 14, marginTop: 4 }]}>{serverTime}</Text>
        </View>
      ) : null}

      {/* Mode toggle */}
      <Pressable onLongPress={onLongPressMode} style={styles.segment}>
        <Pressable
          onPress={() => setDirection("IN")}
          style={[styles.segmentBtn, direction === "IN" && styles.segmentIn]}
        >
          <Text style={[styles.segmentText, direction === "IN" && styles.segmentTextActive]}>IN</Text>
        </Pressable>
        <Pressable
          onPress={() => setDirection("OUT")}
          style={[styles.segmentBtn, direction === "OUT" && styles.segmentOut]}
        >
          <Text style={[styles.segmentText, direction === "OUT" && styles.segmentTextActive]}>OUT</Text>
        </Pressable>
      </Pressable>

      {/* Camera + overlays */}
      <View style={styles.cameraWrap}>
        <CameraView
          style={StyleSheet.absoluteFill}
          facing="back"
          barcodeScannerSettings={{ barcodeTypes: ["qr"] }}
          // Keep handler active to detect "QR still in frame" and extend the leave timer.
          onBarcodeScanned={onBarcodeScanned}
        />

        {showBlur && <BlurView intensity={35} tint="dark" style={StyleSheet.absoluteFill} />}

        {/* Sync progress bar */}
        {syncing && (
          <View style={styles.syncWrap}>
            <View style={[styles.syncFill, { width: `${syncPct}%` }]} />
            <Text style={styles.syncText}>Syncing {syncProgress}/{syncTotal}</Text>
          </View>
        )}

        {/* Scan frame */}
        <View style={styles.frameCenter}>
          <Animated.View
            style={[
              styles.scanFrame,
              (scanState === "FOUND" || scanState === "VALIDATING") && {
                transform: [
                  {
                    scale: pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.02] }),
                  },
                ],
              },
            ]}
          >
            <Animated.View
              style={[
                styles.scanLine,
                {
                  transform: [
                    {
                      translateY: scanLineY.interpolate({
                        inputRange: [0, 1],
                        outputRange: [8, 210],
                      }),
                    },
                  ],
                  opacity: scanState === "SEARCHING" ? 0.95 : 0.35,
                },
              ]}
            />
          </Animated.View>
        </View>

        {/* Status card */}
        <View style={styles.statusCard}>
          <Text style={styles.statusTitle}>{statusText.t}</Text>
          <Text style={styles.statusSub}>{statusText.s}</Text>

          <Pressable onPress={() => navigation.navigate("History")} style={styles.historyBtn}>
            <Text style={styles.historyText}>View History</Text>
          </Pressable>
        </View>
      </View>

      {/* Last scanned user card */}
      {lastCard && (
        <View style={styles.lastCard}>
          <View style={{ flex: 1 }}>
            <Text style={styles.lastName} numberOfLines={1}>
              {lastCard.name || "—"}
            </Text>
            {!!lastCard.company && (
              <Text style={styles.lastCompany} numberOfLines={1}>
                {lastCard.company}
              </Text>
            )}
            {!!lastCard.message && (
              <Text style={styles.lastMsg} numberOfLines={2}>
                {lastCard.message}
              </Text>
            )}
          </View>
          <View style={styles.lastMeta}>
            <Text style={styles.lastDir}>{direction}</Text>
            <Text style={styles.lastTime}>{lastCard.time}</Text>
          </View>
        </View>
      )}

      {/* Admin quick link for admins */}
      {role === "ADMIN" && (
        <Pressable onPress={() => navigation.navigate("Admin")} style={styles.adminPill}>
          <Text style={styles.adminText}>Admin</Text>
        </Pressable>
      )}


<Modal visible={manualOpen} transparent animationType="fade" onRequestClose={() => setManualOpen(false)}>
  <View style={styles.modalBackdrop}>
    <View style={styles.modalCard}>
      <Text style={styles.modalTitle}>Manual search</Text>
      <Text style={styles.modalSub}>Search by name, email, phone, company, designation, or QR.</Text>

      <TextInput
        value={manualQ}
        onChangeText={(t) => { setManualQ(t); setManualSelected(null); runTicketSearch(t); }}
        placeholder="Type to search…"
        placeholderTextColor="rgba(255,255,255,0.55)"
        style={styles.modalInput}
        autoCapitalize="none"
      />

      <View style={{ flex: 1, marginTop: 10 }}>
        {manualLoading ? (
          <Text style={styles.modalHint}>Searching…</Text>
        ) : manualItems.length ? (
          <FlatList
            data={manualItems}
            keyExtractor={(it) => String(it.ticket_id || it.qr_code)}
            renderItem={({ item }) => {
              const a = item.attendee || {};
              const selected = manualSelected?.ticket_id === item.ticket_id;
              return (
                <Pressable
                  onPress={() => setManualSelected(item)}
                  style={[styles.ticketRow, selected && styles.ticketRowActive]}
                >
                  <Text style={styles.ticketName}>{a.full_name || "Unknown"}</Text>
                  <Text style={styles.ticketMeta}>
                    {item.qr_code} {a.phone ? ` • ${a.phone}` : ""} {a.email ? ` • ${a.email}` : ""}
                  </Text>
                  <Text style={styles.ticketMeta}>
                    {a.company || ""}{a.designation ? ` • ${a.designation}` : ""}
                  </Text>
                </Pressable>
              );
            }}
          />
        ) : (
          <Text style={styles.modalHint}>No results.</Text>
        )}
      </View>

      <View style={{ flexDirection: "row", gap: 10, marginTop: 12 }}>
        <Pressable style={[styles.modalBtn, styles.modalBtnGhost]} onPress={() => setManualOpen(false)}>
          <Text style={styles.modalBtnText}>Close</Text>
        </Pressable>

        <Pressable
          style={[styles.modalBtn, !manualSelected && { opacity: 0.5 }]}
          disabled={!manualSelected}
          onPress={async () => {
            try {
              const qr_code = manualSelected?.qr_code;
              if (!qr_code) return;
              setManualOpen(false);
              // Run same scan flow as camera
              await onScanPayload({ qr_code });
            } catch (e) {}
          }}
        >
          <Text style={styles.modalBtnText}>Submit {settings?.direction === "IN" ? "IN" : "OUT"}</Text>
        </Pressable>
      </View>
    </View>
  </View>
</Modal>

    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0B1220", paddingTop: Platform.OS === "android" ? 10 : 0 },
  center: { flex: 1, justifyContent: "center", alignItems: "center", padding: 20, backgroundColor: "#0B1220" },
  text: { color: "white", fontSize: 16, textAlign: "center", marginBottom: 12, fontWeight: "700" },
  primaryBtn: { backgroundColor: "#79C2FF", paddingVertical: 12, paddingHorizontal: 16, borderRadius: 12 },
  primaryBtnText: { color: "#0B1220", fontWeight: "900" },

  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: 14, paddingBottom: 10 },
  iconBtn: { width: 42, height: 42, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.06)", alignItems: "center", justifyContent: "center" },
  iconText: { color: "white", fontSize: 18, fontWeight: "900" },
  headerTitle: { flex: 1, textAlign: "center", color: "white", fontSize: 18, fontWeight: "900" },
  netBadge: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999 },
  netOn: { backgroundColor: "rgba(103,232,167,0.18)" },
  netOff: { backgroundColor: "rgba(255,138,138,0.18)" },
  netText: { color: "white", fontSize: 12, fontWeight: "900" },

  countersRow: { flexDirection: "row", gap: 10, paddingHorizontal: 14, paddingBottom: 10 },
  counterCard: {
    flex: 1,
    backgroundColor: "rgba(255,255,255,0.06)",
    borderRadius: 16,
    padding: 12,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.10)",
  },
  counterLabel: { color: "rgba(255,255,255,0.70)", fontWeight: "800" },
  counterValue: { color: "white", fontSize: 20, fontWeight: "900", marginTop: 6 },

  segment: { flexDirection: "row", marginHorizontal: 14, backgroundColor: "rgba(255,255,255,0.06)", borderRadius: 16, padding: 6, marginBottom: 10 },
  segmentBtn: { flex: 1, height: 44, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  segmentText: { color: "rgba(255,255,255,0.75)", fontWeight: "900", letterSpacing: 0.6 },
  segmentTextActive: { color: "#0B1220" },
  segmentIn: { backgroundColor: "#67E8A7" },
  segmentOut: { backgroundColor: "#FFB86B" },

  cameraWrap: { flex: 1, marginHorizontal: 14, marginBottom: 12, borderRadius: 22, overflow: "hidden", backgroundColor: "black" },

  syncWrap: {
    position: "absolute",
    top: 10,
    left: 12,
    right: 12,
    height: 36,
    backgroundColor: "rgba(0,0,0,0.55)",
    borderRadius: 18,
    overflow: "hidden",
    justifyContent: "center",
  },
  syncFill: { position: "absolute", left: 0, top: 0, bottom: 0, backgroundColor: "#67E8A7" },
  syncText: { color: "white", fontSize: 13, fontWeight: "900", textAlign: "center" },

  frameCenter: { ...StyleSheet.absoluteFillObject, justifyContent: "center", alignItems: "center" },
  scanFrame: {
    width: 270,
    height: 270,
    borderRadius: 26,
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.25)",
    backgroundColor: "rgba(0,0,0,0.10)",
  },
  scanLine: { position: "absolute", left: 12, right: 12, height: 2, borderRadius: 2, backgroundColor: "rgba(121,194,255,0.95)" },

  statusCard: {
    position: "absolute",
    left: 12,
    right: 12,
    bottom: 12,
    borderRadius: 18,
    padding: 14,
    backgroundColor: "rgba(0,0,0,0.45)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.12)",
  },
  statusTitle: { color: "white", fontSize: 16, fontWeight: "1000" },
  statusSub: { color: "rgba(255,255,255,0.82)", fontSize: 13, marginTop: 6, fontWeight: "700" },
  historyBtn: {
    marginTop: 10,
    height: 40,
    borderRadius: 14,
    backgroundColor: "rgba(255,255,255,0.10)",
    alignItems: "center",
    justifyContent: "center",
  },
  historyText: { color: "white", fontWeight: "900" },

  lastCard: {
    marginHorizontal: 14,
    marginBottom: 10,
    backgroundColor: "rgba(255,255,255,0.06)",
    borderRadius: 18,
    padding: 14,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.10)",
    flexDirection: "row",
    gap: 12,
    alignItems: "center",
  },
  lastName: { color: "white", fontWeight: "900", fontSize: 16 },
  lastCompany: { color: "rgba(255,255,255,0.75)", marginTop: 4, fontWeight: "700" },
  lastMsg: { color: "rgba(255,255,255,0.65)", marginTop: 6, fontWeight: "700" },
  lastMeta: { alignItems: "flex-end" },
  lastDir: { color: "#79C2FF", fontWeight: "900" },
  lastTime: { color: "rgba(255,255,255,0.75)", marginTop: 6, fontWeight: "700" },

  adminPill: {
    position: "absolute",
    top: Platform.OS === "android" ? 56 : 46,
    right: 14,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: "rgba(121,194,255,0.18)",
  },
  adminText: { color: "white", fontWeight: "900", fontSize: 12 },
});
