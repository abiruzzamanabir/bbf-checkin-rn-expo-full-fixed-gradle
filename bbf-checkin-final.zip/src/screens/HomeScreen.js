import React, { useEffect, useMemo, useState } from "react";
import { View, Text, Pressable, StyleSheet, Modal, FlatList } from "react-native";
import { clearToken } from "../storage/token";
import { logout, me } from "../api/auth";
import { fetchEvents } from "../api/events";
import { fetchGates } from "../api/gates";
import { getSettings, setSettings } from "../storage/settings";

function SelectModal({ visible, title, items, keyExtractor, renderLabel, onPick, onClose }) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.modalBackdrop}>
        <View style={styles.modalCard}>
          <Text style={styles.modalTitle}>{title}</Text>
          <FlatList
            data={items}
            keyExtractor={keyExtractor}
            ItemSeparatorComponent={() => <View style={styles.sep} />}
            renderItem={({ item }) => (
              <Pressable style={styles.modalItem} onPress={() => onPick(item)}>
                <Text style={styles.modalItemText}>{renderLabel(item)}</Text>
              </Pressable>
            )}
          />
          <Pressable style={[styles.btn, styles.btn2]} onPress={onClose}>
            <Text style={styles.btnText}>Close</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

export default function HomeScreen({ navigation }) {
  const [user, setUser] = useState(null);

  const [events, setEvents] = useState([]);
  const [gates, setGates] = useState([]);

  const [settings, setLocalSettings] = useState({ event: null, gate: null, direction: "IN" });

  const [eventModal, setEventModal] = useState(false);
  const [gateModal, setGateModal] = useState(false);

  useEffect(() => {
    (async () => {
      // auth check
      try {
        const data = await me();
        setUser(data.user || data);
      } catch {
        await clearToken();
        navigation.reset({ index: 0, routes: [{ name: "Login" }] });
        return;
      }

      // load settings + events
      const s = await getSettings();
      setLocalSettings(s);

      const evs = await fetchEvents();
      setEvents(evs);

      // ensure event exists
      let chosenEvent = s.event;
      if (!chosenEvent && evs.length) chosenEvent = evs[0];

      if (chosenEvent) {
        const gs = await fetchGates(chosenEvent.slug);
        setGates(gs);

        let chosenGate = s.gate;
        if (!chosenGate && gs.length) chosenGate = gs.find(g => g.is_active) || gs[0];

        const next = await setSettings({ event: chosenEvent, gate: chosenGate });
        setLocalSettings(next);
      }
    })();
  }, [navigation]);

  const eventName = settings.event?.name || "Select event";
  const gateName = settings.gate?.name ? `${settings.gate.name} (${settings.gate.code})` : "Select gate";

  async function onPickEvent(ev) {
    setEventModal(false);
    const gs = await fetchGates(ev.slug);
    setGates(gs);
    const firstGate = gs.length ? (gs.find(g => g.is_active) || gs[0]) : null;
    const next = await setSettings({ event: ev, gate: firstGate });
    setLocalSettings(next);
  }

  async function onPickGate(g) {
    setGateModal(false);
    const next = await setSettings({ gate: g });
    setLocalSettings(next);
  }

  async function setDirection(direction) {
    const next = await setSettings({ direction });
    setLocalSettings(next);
  }

  async function onLogout() {
    try { await logout(); } catch {}
    await clearToken();
    navigation.reset({ index: 0, routes: [{ name: "Login" }] });
  }

  const canScan = !!settings.event && !!settings.direction;

  return (
    <View style={styles.wrap}>
      <Text style={styles.title}>BBF Check-in</Text>
      <Text style={styles.sub}>
        {user ? `Logged in as: ${user.name || "User"} (${user.role || "role"})` : "Loading profile..."}
      </Text>

      <Text style={styles.sectionTitle}>Setup</Text>

      <Pressable style={styles.selector} onPress={() => setEventModal(true)}>
        <Text style={styles.selectorLabel}>Event</Text>
        <Text style={styles.selectorValue}>{eventName}</Text>
      </Pressable>

      <Pressable
        style={[styles.selector, !settings.event && { opacity: 0.5 }]}
        disabled={!settings.event}
        onPress={() => setGateModal(true)}
      >
        <Text style={styles.selectorLabel}>Gate</Text>
        <Text style={styles.selectorValue}>{gateName}</Text>
      </Pressable>

      <View style={styles.toggleRow}>
        <Pressable
          style={[styles.toggleBtn, settings.direction === "IN" && styles.toggleBtnActive]}
          onPress={() => setDirection("IN")}
        >
          <Text style={styles.toggleText}>IN</Text>
        </Pressable>
        <Pressable
          style={[styles.toggleBtn, settings.direction === "OUT" && styles.toggleBtnActive]}
          onPress={() => setDirection("OUT")}
        >
          <Text style={styles.toggleText}>OUT</Text>
        </Pressable>
      </View>

      <Pressable
        style={[styles.btn, !canScan && { opacity: 0.5 }]}
        disabled={!canScan}
        onPress={() => navigation.navigate("Scanner")}
      >
        <Text style={styles.btnText}>Open Scanner</Text>
      </Pressable>

      <Pressable style={[styles.btn, styles.btn2]} onPress={onLogout}>
        <Text style={styles.btnText}>Logout</Text>
      </Pressable>

      <SelectModal
        visible={eventModal}
        title="Select Event"
        items={events}
        keyExtractor={(i) => String(i.id)}
        renderLabel={(i) => i.name}
        onPick={onPickEvent}
        onClose={() => setEventModal(false)}
      />

      <SelectModal
        visible={gateModal}
        title="Select Gate"
        items={gates.filter(g => g.is_active)}
        keyExtractor={(i) => String(i.id)}
        renderLabel={(i) => `${i.name} (${i.code})`}
        onPick={onPickGate}
        onClose={() => setGateModal(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, padding: 18, backgroundColor: "#0b1220" },
  title: { color: "white", fontSize: 26, fontWeight: "800", marginTop: 10 },
  sub: { color: "#b6c2d9", marginTop: 8, marginBottom: 18 },

  sectionTitle: { color: "white", fontSize: 16, fontWeight: "800", marginBottom: 10 },

  selector: { backgroundColor: "#101a2d", borderWidth: 1, borderColor: "#1e2b45", borderRadius: 14, padding: 12, marginBottom: 10 },
  selectorLabel: { color: "#7f8fb3", fontWeight: "700", marginBottom: 4 },
  selectorValue: { color: "white", fontWeight: "800" },

  toggleRow: { flexDirection: "row", gap: 10, marginTop: 6, marginBottom: 14 },
  toggleBtn: { flex: 1, backgroundColor: "#101a2d", borderWidth: 1, borderColor: "#1e2b45", padding: 12, borderRadius: 14, alignItems: "center" },
  toggleBtnActive: { backgroundColor: "#2f6bff", borderColor: "#2f6bff" },
  toggleText: { color: "white", fontWeight: "900" },

  btn: { backgroundColor: "#2f6bff", padding: 14, borderRadius: 12, alignItems: "center", marginTop: 10 },
  btn2: { backgroundColor: "#27324a" },
  btnText: { color: "white", fontWeight: "800" },

  modalBackdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "center", padding: 18 },
  modalCard: { backgroundColor: "#101a2d", borderRadius: 16, borderWidth: 1, borderColor: "#1e2b45", padding: 14, maxHeight: "80%" },
  modalTitle: { color: "white", fontSize: 18, fontWeight: "900", marginBottom: 10 },
  modalItem: { paddingVertical: 12, paddingHorizontal: 10, borderRadius: 10 },
  modalItemText: { color: "white", fontWeight: "800" },
  sep: { height: 1, backgroundColor: "#1e2b45" },
});
